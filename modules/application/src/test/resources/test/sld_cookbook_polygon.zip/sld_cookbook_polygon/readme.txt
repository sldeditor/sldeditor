This archive is from the GeoServer SLD Cookbook, which is available at:
http://docs.geoserver.org/stable/en/user/styling/sld-cookbook/index.html

For more information go to:
http://geoserver.org